#!/bin/bash

# Define GMT offset
GMT_OFFSET="+6"
TEMPLATE_DIR="./templates"  # Directory containing template files
OUTPUT_FILE="../output.txt"  # File to store all output from nuclei

# Get the list of all template files in the templates directory
templates=("$TEMPLATE_DIR"/*.yaml)

# Check if there are any templates to process
if [ ${#templates[@]} -eq 0 ]; then
    echo "[-] Error: No template files found in the ${TEMPLATE_DIR} directory."
    exit 1
fi

# Total number of templates
total_templates=${#templates[@]}
echo "[+] Found $total_templates template(s) in the ${TEMPLATE_DIR} directory."

# Function to run nuclei with a template
run_nuclei_template() {
    local template=$1
    local current_index=$2

    # Record start time in GMT+6
    local start_time
    start_time=$(TZ="GMT${GMT_OFFSET}" date '+%Y-%m-%d %I:%M')
    echo -e "\n[${start_time}] Processing template ${current_index}/${total_templates}: ${template}"

    # Run nuclei with the given template and append the output to the output.txt file
    nuclei -l subdomains.txt -t "$TEMPLATE_DIR/$template" -bs 50 | tee -a "$OUTPUT_FILE"  # Append the result to output.txt

    # Delete the template after processing
    rm -f "$TEMPLATE_DIR/$template"
    echo "[-] Deleted template: $TEMPLATE_DIR/$template"
}

# Loop through each template in the templates directory
for ((i = 0; i < total_templates; i++)); do
    template="${templates[$i]}"
    run_nuclei_template "$(basename "$template")" $((i + 1))
done

# Final notification
echo -e "[+] All templates processing complete."
