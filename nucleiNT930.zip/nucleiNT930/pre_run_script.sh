#!/bin/bash

touch output.txt

cp -r templates ./terminal1

for i in {2..9}; do cp -r terminal1 terminal$i; done

split -n l/9 allSubs.txt filename_

mv filename_aa ./terminal1/subdomains.txt
mv filename_ab ./terminal2/subdomains.txt
mv filename_ac ./terminal3/subdomains.txt
mv filename_ad ./terminal4/subdomains.txt
mv filename_ae ./terminal5/subdomains.txt
mv filename_af ./terminal6/subdomains.txt
mv filename_ag ./terminal7/subdomains.txt
mv filename_ah ./terminal8/subdomains.txt
mv filename_ai ./terminal9/subdomains.txt